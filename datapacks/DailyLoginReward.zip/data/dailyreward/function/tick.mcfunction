execute as @a unless score @s daily.last_claim = current daily.real_day run function dailyreward:claim
