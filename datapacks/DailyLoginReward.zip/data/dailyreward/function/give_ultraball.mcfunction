give @s cobblemon:ultra_ball 10
tellraw @s [{"text":"[Daily Reward] ","color":"gold","bold":true},{"text":"Welcome back! You got ","color":"green"},{"text":"10x Ultra Ball","color":"yellow","bold":true},{"text":"!","color":"green"}]
playsound minecraft:entity.player.levelup ambient @s
