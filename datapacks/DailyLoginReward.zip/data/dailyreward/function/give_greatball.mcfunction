give @s cobblemon:great_ball 10
tellraw @s [{"text":"[Daily Reward] ","color":"gold","bold":true},{"text":"Welcome back! You got ","color":"green"},{"text":"10x Great Ball","color":"aqua","bold":true},{"text":"!","color":"green"}]
playsound minecraft:entity.player.levelup ambient @s
