scoreboard players operation @s daily.last_claim = current daily.real_day
execute store result score @s daily.roll run random value 1..3
execute if score @s daily.roll matches 1 run function dailyreward:give_pokeball
execute if score @s daily.roll matches 2 run function dailyreward:give_greatball
execute if score @s daily.roll matches 3 run function dailyreward:give_ultraball
