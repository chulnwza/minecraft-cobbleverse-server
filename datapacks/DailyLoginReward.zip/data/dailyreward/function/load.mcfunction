scoreboard objectives add daily.last_claim dummy
scoreboard objectives add daily.real_day dummy
scoreboard objectives add daily.roll dummy
