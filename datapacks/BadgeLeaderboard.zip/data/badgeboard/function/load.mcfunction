scoreboard objectives add badges dummy [{"text":"Gym Badges","color":"gold"}]
scoreboard objectives setdisplay sidebar badges
